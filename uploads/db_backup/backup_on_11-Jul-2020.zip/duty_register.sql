#
# TABLE STRUCTURE FOR: activity_log
#

DROP TABLE IF EXISTS `activity_log`;

CREATE TABLE `activity_log` (
  `al_id` int(11) NOT NULL AUTO_INCREMENT,
  `al_description` text NOT NULL,
  `al_ip` varchar(255) NOT NULL,
  `al_flag` int(11) NOT NULL,
  `al_date_time` datetime NOT NULL,
  `al_userid` int(11) NOT NULL,
  PRIMARY KEY (`al_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: attendance
#

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `a_id` int(11) NOT NULL AUTO_INCREMENT,
  `a_doa` date NOT NULL,
  `a_sec` int(11) NOT NULL,
  `a_details` text NOT NULL,
  `a_date` date NOT NULL,
  `a_time` time NOT NULL,
  `a_flag` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `attendance` (`a_id`, `a_doa`, `a_sec`, `a_details`, `a_date`, `a_time`, `a_flag`, `user_id`) VALUES (1, '2020-07-02', 1, 'a:17:{i:14;s:2:\"SM\";i:16;s:2:\"S1\";i:15;s:2:\"S2\";i:20;s:2:\"S3\";i:21;s:3:\"AVL\";i:22;s:2:\"SM\";i:30;s:2:\"S1\";i:31;s:3:\"L/O\";i:32;s:2:\"S2\";i:33;s:2:\"S3\";i:34;s:3:\"AVL\";i:35;s:0:\"\";i:36;s:0:\"\";i:37;s:0:\"\";i:50;s:0:\"\";i:52;s:0:\"\";i:53;s:0:\"\";}', '2020-07-08', '23:45:11', 1, 1);
INSERT INTO `attendance` (`a_id`, `a_doa`, `a_sec`, `a_details`, `a_date`, `a_time`, `a_flag`, `user_id`) VALUES (2, '2020-07-02', 8, 'a:12:{i:77;s:3:\"AVL\";i:78;s:2:\"S3\";i:79;s:2:\"S2\";i:80;s:2:\"S1\";i:81;s:2:\"SM\";i:82;s:0:\"\";i:83;s:0:\"\";i:84;s:0:\"\";i:85;s:0:\"\";i:86;s:0:\"\";i:87;s:0:\"\";i:88;s:0:\"\";}', '2020-07-09', '09:29:39', 1, 1);
INSERT INTO `attendance` (`a_id`, `a_doa`, `a_sec`, `a_details`, `a_date`, `a_time`, `a_flag`, `user_id`) VALUES (3, '2020-07-02', 2, 'a:3:{i:23;s:2:\"SM\";i:38;s:2:\"S1\";i:39;s:2:\"S2\";}', '2020-07-09', '13:56:01', 1, 1);


#
# TABLE STRUCTURE FOR: batch
#

DROP TABLE IF EXISTS `batch`;

CREATE TABLE `batch` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT,
  `b_name` varchar(255) NOT NULL,
  `b_start` varchar(255) NOT NULL,
  `b_end` varchar(255) NOT NULL,
  `b_duty_cycle` int(11) NOT NULL,
  `b_date` date NOT NULL,
  `b_time` time NOT NULL,
  `b_flag` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `batch` (`b_id`, `b_name`, `b_start`, `b_end`, `b_duty_cycle`, `b_date`, `b_time`, `b_flag`, `user_id`) VALUES (1, 'A', '1989', '1995', 1, '2020-01-18', '16:26:35', 1, 1);
INSERT INTO `batch` (`b_id`, `b_name`, `b_start`, `b_end`, `b_duty_cycle`, `b_date`, `b_time`, `b_flag`, `user_id`) VALUES (2, 'B', '1996', '2003', 2, '2020-01-18', '16:33:35', 1, 1);
INSERT INTO `batch` (`b_id`, `b_name`, `b_start`, `b_end`, `b_duty_cycle`, `b_date`, `b_time`, `b_flag`, `user_id`) VALUES (3, 'C', '2004', '2010', 2, '2020-01-20', '00:09:18', 1, 1);
INSERT INTO `batch` (`b_id`, `b_name`, `b_start`, `b_end`, `b_duty_cycle`, `b_date`, `b_time`, `b_flag`, `user_id`) VALUES (5, 'D', '2011', '2016', 2, '2020-01-22', '13:32:26', 1, 1);


#
# TABLE STRUCTURE FOR: designation
#

DROP TABLE IF EXISTS `designation`;

CREATE TABLE `designation` (
  `ds_id` int(11) NOT NULL AUTO_INCREMENT,
  `ds_name` varchar(255) NOT NULL,
  `ds_date` date NOT NULL,
  `ds_time` time NOT NULL,
  `ds_flag` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`ds_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (1, 'Officer In-Charge', '0000-00-00', '00:00:00', 1, 0);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (2, 'Additional Officer In-charge', '2020-01-19', '15:34:59', 1, 1);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (3, 'Inspector', '0000-00-00', '00:00:00', 1, 0);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (4, 'SI', '2020-06-10', '14:02:07', 1, 1);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (5, 'ASI', '2020-06-10', '14:02:16', 1, 1);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (6, 'Constable', '2020-06-10', '14:02:24', 1, 1);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (8, 'KHG', '2020-06-27', '08:36:39', 1, 1);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (9, 'L/KHG', '2020-06-27', '08:36:47', 1, 1);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (10, 'Civic Volunteer', '2020-06-27', '08:36:58', 1, 1);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (12, 'Group D', '2020-06-27', '08:45:26', 1, 1);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (13, 'SL III', '2020-06-30', '20:56:58', 1, 1);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (14, 'SD', '2020-06-30', '20:57:06', 1, 1);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (15, 'CO', '2020-06-30', '20:57:14', 1, 1);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (16, 'SL I', '2020-06-30', '20:57:45', 1, 1);
INSERT INTO `designation` (`ds_id`, `ds_name`, `ds_date`, `ds_time`, `ds_flag`, `user_id`) VALUES (17, 'CA', '2020-06-30', '20:57:57', 1, 1);


#
# TABLE STRUCTURE FOR: duty_assigned
#

DROP TABLE IF EXISTS `duty_assigned`;

CREATE TABLE `duty_assigned` (
  `da_id` int(11) NOT NULL AUTO_INCREMENT,
  `da_e_id` int(11) NOT NULL,
  `da_staff_id` varchar(255) NOT NULL,
  `da_date` date NOT NULL,
  `da_time` time NOT NULL,
  `da_flag` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`da_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `duty_assigned` (`da_id`, `da_e_id`, `da_staff_id`, `da_date`, `da_time`, `da_flag`, `user_id`) VALUES (1, 3, '19', '2020-07-02', '11:43:45', 1, 1);
INSERT INTO `duty_assigned` (`da_id`, `da_e_id`, `da_staff_id`, `da_date`, `da_time`, `da_flag`, `user_id`) VALUES (2, 1, '39', '2020-07-02', '11:45:00', 1, 1);
INSERT INTO `duty_assigned` (`da_id`, `da_e_id`, `da_staff_id`, `da_date`, `da_time`, `da_flag`, `user_id`) VALUES (4, 5, '25', '2020-07-02', '11:46:34', 1, 1);
INSERT INTO `duty_assigned` (`da_id`, `da_e_id`, `da_staff_id`, `da_date`, `da_time`, `da_flag`, `user_id`) VALUES (6, 4, '31', '2020-07-02', '20:08:53', 1, 2);
INSERT INTO `duty_assigned` (`da_id`, `da_e_id`, `da_staff_id`, `da_date`, `da_time`, `da_flag`, `user_id`) VALUES (7, 6, '48', '2020-07-02', '20:10:22', 1, 2);
INSERT INTO `duty_assigned` (`da_id`, `da_e_id`, `da_staff_id`, `da_date`, `da_time`, `da_flag`, `user_id`) VALUES (10, 8, '31', '2020-07-03', '08:42:51', 1, 3);
INSERT INTO `duty_assigned` (`da_id`, `da_e_id`, `da_staff_id`, `da_date`, `da_time`, `da_flag`, `user_id`) VALUES (11, 9, '31', '2020-07-03', '08:46:35', 1, 3);
INSERT INTO `duty_assigned` (`da_id`, `da_e_id`, `da_staff_id`, `da_date`, `da_time`, `da_flag`, `user_id`) VALUES (12, 10, '25', '2020-07-03', '08:46:57', 1, 3);
INSERT INTO `duty_assigned` (`da_id`, `da_e_id`, `da_staff_id`, `da_date`, `da_time`, `da_flag`, `user_id`) VALUES (13, 11, '48', '2020-07-03', '08:47:14', 1, 3);
INSERT INTO `duty_assigned` (`da_id`, `da_e_id`, `da_staff_id`, `da_date`, `da_time`, `da_flag`, `user_id`) VALUES (15, 13, '25', '2020-07-03', '08:58:18', 1, 3);
INSERT INTO `duty_assigned` (`da_id`, `da_e_id`, `da_staff_id`, `da_date`, `da_time`, `da_flag`, `user_id`) VALUES (16, 14, '48', '2020-07-03', '08:58:30', 1, 3);
INSERT INTO `duty_assigned` (`da_id`, `da_e_id`, `da_staff_id`, `da_date`, `da_time`, `da_flag`, `user_id`) VALUES (18, 12, '31', '2020-07-03', '09:02:40', 1, 3);


#
# TABLE STRUCTURE FOR: duty_cycle
#

DROP TABLE IF EXISTS `duty_cycle`;

CREATE TABLE `duty_cycle` (
  `dc_id` int(11) NOT NULL AUTO_INCREMENT,
  `dc_stid` int(11) DEFAULT NULL,
  `dc_dsid` varchar(45) DEFAULT NULL,
  `dc_batch` varchar(45) DEFAULT NULL,
  `dc_datetime` datetime DEFAULT NULL,
  `dc_flag` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`dc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: event
#

DROP TABLE IF EXISTS `event`;

CREATE TABLE `event` (
  `e_id` int(11) NOT NULL AUTO_INCREMENT,
  `e_name` varchar(255) NOT NULL,
  `e_adate` date NOT NULL,
  `e_atime` time NOT NULL,
  `e_details` text NOT NULL,
  `e_SI_assign` int(11) NOT NULL,
  `e_ASI_assign` int(11) NOT NULL,
  `e_Constable_assign` int(11) NOT NULL,
  `e_KHG_assign` int(11) NOT NULL,
  `e_LKHG_assign` int(11) NOT NULL,
  `e_Civic_assign` int(11) NOT NULL,
  `e_date` date NOT NULL,
  `e_time` time NOT NULL,
  `e_flag` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`e_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `event` (`e_id`, `e_name`, `e_adate`, `e_atime`, `e_details`, `e_SI_assign`, `e_ASI_assign`, `e_Constable_assign`, `e_KHG_assign`, `e_LKHG_assign`, `e_Civic_assign`, `e_date`, `e_time`, `e_flag`, `user_id`) VALUES (1, 'ACR', '2020-07-01', '12:30:00', 'ACR', 0, 0, 1, 0, 0, 0, '2020-07-02', '11:37:18', 1, 1);
INSERT INTO `event` (`e_id`, `e_name`, `e_adate`, `e_atime`, `e_details`, `e_SI_assign`, `e_ASI_assign`, `e_Constable_assign`, `e_KHG_assign`, `e_LKHG_assign`, `e_Civic_assign`, `e_date`, `e_time`, `e_flag`, `user_id`) VALUES (2, 'Short', '2020-07-01', '12:30:00', 'Short', 0, 1, 0, 0, 0, 0, '2020-07-02', '11:38:28', 0, 1);
INSERT INTO `event` (`e_id`, `e_name`, `e_adate`, `e_atime`, `e_details`, `e_SI_assign`, `e_ASI_assign`, `e_Constable_assign`, `e_KHG_assign`, `e_LKHG_assign`, `e_Civic_assign`, `e_date`, `e_time`, `e_flag`, `user_id`) VALUES (3, 'NCR', '2020-07-01', '12:30:00', 'NCR', 1, 0, 0, 0, 0, 0, '2020-07-02', '11:38:58', 1, 1);
INSERT INTO `event` (`e_id`, `e_name`, `e_adate`, `e_atime`, `e_details`, `e_SI_assign`, `e_ASI_assign`, `e_Constable_assign`, `e_KHG_assign`, `e_LKHG_assign`, `e_Civic_assign`, `e_date`, `e_time`, `e_flag`, `user_id`) VALUES (12, 'ACR', '2020-07-02', '12:30:00', 'ACR', 0, 0, 1, 0, 0, 0, '2020-07-03', '08:56:15', 1, 3);
INSERT INTO `event` (`e_id`, `e_name`, `e_adate`, `e_atime`, `e_details`, `e_SI_assign`, `e_ASI_assign`, `e_Constable_assign`, `e_KHG_assign`, `e_LKHG_assign`, `e_Civic_assign`, `e_date`, `e_time`, `e_flag`, `user_id`) VALUES (13, 'High Court New Building', '2020-07-02', '12:30:00', 'High Court New Building', 0, 1, 0, 0, 0, 0, '2020-07-03', '08:53:44', 1, 3);
INSERT INTO `event` (`e_id`, `e_name`, `e_adate`, `e_atime`, `e_details`, `e_SI_assign`, `e_ASI_assign`, `e_Constable_assign`, `e_KHG_assign`, `e_LKHG_assign`, `e_Civic_assign`, `e_date`, `e_time`, `e_flag`, `user_id`) VALUES (14, 'Special Striking', '2020-07-02', '09:30:00', 'Special Striking', 1, 0, 0, 0, 0, 0, '2020-07-03', '08:54:13', 1, 3);


#
# TABLE STRUCTURE FOR: leave_structure
#

DROP TABLE IF EXISTS `leave_structure`;

CREATE TABLE `leave_structure` (
  `l_id` int(11) NOT NULL AUTO_INCREMENT,
  `l_type` varchar(255) NOT NULL,
  `l_date` date NOT NULL,
  `l_time` time NOT NULL,
  `l_flag` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`l_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `leave_structure` (`l_id`, `l_type`, `l_date`, `l_time`, `l_flag`, `user_id`) VALUES (1, 'CCL', '2020-01-27', '15:49:28', 1, 1);
INSERT INTO `leave_structure` (`l_id`, `l_type`, `l_date`, `l_time`, `l_flag`, `user_id`) VALUES (2, 'CL', '2020-01-27', '15:49:39', 1, 1);
INSERT INTO `leave_structure` (`l_id`, `l_type`, `l_date`, `l_time`, `l_flag`, `user_id`) VALUES (3, 'EL', '2020-06-27', '13:23:52', 1, 1);
INSERT INTO `leave_structure` (`l_id`, `l_type`, `l_date`, `l_time`, `l_flag`, `user_id`) VALUES (4, 'Medical', '2020-06-27', '13:12:09', 1, 1);


#
# TABLE STRUCTURE FOR: sections
#

DROP TABLE IF EXISTS `sections`;

CREATE TABLE `sections` (
  `sc_id` int(11) NOT NULL AUTO_INCREMENT,
  `sc_name` varchar(255) NOT NULL,
  `sc_date` date NOT NULL,
  `sc_time` time NOT NULL,
  `sc_flag` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`sc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `sections` (`sc_id`, `sc_name`, `sc_date`, `sc_time`, `sc_flag`, `user_id`) VALUES (1, 'FOOT & FINGER PRINT ', '2020-01-19', '14:42:39', 1, 1);
INSERT INTO `sections` (`sc_id`, `sc_name`, `sc_date`, `sc_time`, `sc_flag`, `user_id`) VALUES (2, 'POTRAIT PARLEY', '2020-01-19', '23:20:09', 1, 1);
INSERT INTO `sections` (`sc_id`, `sc_name`, `sc_date`, `sc_time`, `sc_flag`, `user_id`) VALUES (3, 'PHOTOGRAPHY', '2020-01-19', '09:04:31', 1, 1);
INSERT INTO `sections` (`sc_id`, `sc_name`, `sc_date`, `sc_time`, `sc_flag`, `user_id`) VALUES (4, 'PLAN MAKING', '2020-01-25', '13:46:26', 1, 1);
INSERT INTO `sections` (`sc_id`, `sc_name`, `sc_date`, `sc_time`, `sc_flag`, `user_id`) VALUES (5, 'VIDEOGRAPHY', '2020-01-25', '13:55:18', 1, 1);
INSERT INTO `sections` (`sc_id`, `sc_name`, `sc_date`, `sc_time`, `sc_flag`, `user_id`) VALUES (6, 'BACK-PACK', '2020-01-25', '13:55:29', 1, 1);
INSERT INTO `sections` (`sc_id`, `sc_name`, `sc_date`, `sc_time`, `sc_flag`, `user_id`) VALUES (7, 'Civic Volunteer', '2020-06-27', '08:36:31', 1, 1);
INSERT INTO `sections` (`sc_id`, `sc_name`, `sc_date`, `sc_time`, `sc_flag`, `user_id`) VALUES (8, 'CPC', '2020-06-30', '20:56:06', 1, 1);


#
# TABLE STRUCTURE FOR: staff
#

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `st_id` int(11) NOT NULL AUTO_INCREMENT,
  `st_section` int(11) NOT NULL,
  `st_designation` int(11) NOT NULL,
  `stname` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `doj` date NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `batch` varchar(255) NOT NULL,
  `batch_serial` int(11) NOT NULL,
  `duty_flag` int(11) NOT NULL,
  `last_duty_date` date NOT NULL,
  `st_date` date NOT NULL,
  `st_time` time NOT NULL,
  `st_flag` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`st_id`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=latin1;

INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (14, 1, 4, 'RANOJIT ADHIKARY', 'Male', '1990-01-01', '98311-05285', 'n@gmail.com', 'male.jpg', '1', 1, 0, '0000-00-00', '2020-01-22', '15:51:05', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (15, 1, 4, 'KALYAN SARKAR', 'Male', '1998-01-01', '98307-25526', '', 'male.jpg', '1', 3, 0, '0000-00-00', '2020-01-22', '15:56:58', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (16, 1, 4, 'SUMAN BANERJEE', 'Male', '2005-01-01', '98303-23890', '', 'male.jpg', '1', 2, 0, '0000-00-00', '2020-01-22', '15:57:28', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (17, 4, 4, 'GANESH CH. GARAI', 'Male', '1993-01-01', '98301-71447', 'd@gmail.com', 'male.jpg', '1', 4, 0, '0000-00-00', '2020-01-22', '15:53:55', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (18, 4, 4, 'PARTAH ROY', 'Male', '2012-01-01', '90073-83030', '', 'male.jpg', '1', 5, 0, '0000-00-00', '2020-01-22', '15:57:52', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (19, 4, 4, 'BIKASH CH. MAJEE', 'Female', '2005-01-01', '2255887744', 'b@gmail.com', 'male.jpg', '1', 6, 0, '0000-00-00', '2020-01-24', '22:21:40', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (20, 1, 5, 'SHYAMAL KR. MONDAL', 'Male', '1990-01-01', '90511-15715', '', 'male.jpg', '1', 7, 0, '0000-00-00', '2020-01-25', '13:48:11', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (21, 1, 5, 'ASHIM MAJUMDER', 'Male', '1990-01-01', '98305-80609', 's@gmail.com', 'male.jpg', '1', 8, 0, '0000-00-00', '2020-01-25', '13:49:06', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (22, 1, 5, 'KRISHNA GOPAL ROY', 'Male', '1991-01-01', '98311-47479', 'd@gmail.com', 'male.jpg', '1', 9, 0, '2020-06-10', '2020-01-25', '13:51:20', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (23, 2, 5, 'ANUP KR. SARKAR', 'Male', '2012-01-01', '98301-94059', 'c@gmail.com', 'male.jpg', '1', 10, 0, '2020-06-10', '2020-01-25', '14:03:59', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (24, 3, 5, 'NARAYAN BARUA', 'Male', '2012-01-01', '98747-13104', 'j@gmail.com', 'male.jpg', '1', 12, 0, '2020-06-10', '2020-01-25', '14:05:58', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (25, 3, 5, 'SEKHAR ROY', 'Male', '2012-01-01', '98304-14378', 't@gmail.com', 'male.jpg', '1', 12, 0, '2020-06-10', '2020-01-25', '14:06:35', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (26, 3, 5, 'SANDIP COOMAR', 'Male', '2005-01-01', '98301-39365', 'm@gmail.com', 'male.jpg', '1', 13, 0, '2020-06-10', '2020-01-25', '14:07:20', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (27, 3, 5, 'BIPLADENDU DHAR', 'Male', '2005-01-01', '98310-36395', 'k@gmail.com', 'male.jpg', '1', 14, 0, '2020-06-10', '2020-01-25', '14:07:49', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (30, 1, 6, 'KAMALESH CH. DAS', 'Male', '2012-01-01', '98305-79777', 'n@gmail.com', 'male.jpg', '1', 15, 0, '2020-06-10', '2020-01-25', '14:09:49', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (31, 1, 6, 'CHITTA SHIL', 'Male', '2012-01-01', '98303-16171', 's@gmail.com', 'male.jpg', '1', 16, 0, '2020-06-10', '2020-01-25', '14:10:22', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (32, 1, 6, 'SWARUP DAS', 'Male', '2010-01-01', '98300-28747', 'j@gmail.com', 'male.jpg', '1', 17, 0, '2020-06-10', '2020-01-25', '14:10:55', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (33, 1, 6, 'MRINAL KANTI KHAN', 'Male', '2012-01-01', '94326-13658', 'u@gmail.com', 'male.jpg', '1', 18, 0, '2020-06-10', '2020-01-25', '14:11:20', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (34, 1, 6, 'SOUVIK DUTTA', 'Male', '2020-06-18', '9999988888', 'sou@gmail.com', 'male.jpg', '1', 19, 0, '0000-00-00', '2020-06-18', '21:46:56', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (35, 1, 6, 'JOITISH MONDAL', 'Male', '2020-06-18', '8888877777', 'j@gmail.com', 'male.jpg', '1', 20, 0, '0000-00-00', '2020-06-18', '21:47:41', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (36, 1, 6, 'AMINUR RAHAMAN', 'Male', '2020-06-18', '8888877777', 'a@gmail.com', 'male.jpg', '1', 21, 0, '0000-00-00', '2020-06-18', '21:48:26', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (37, 1, 6, 'MANOJ RAY', 'Male', '2020-06-18', '4444488888', 'm@gmail.com', 'male.jpg', '1', 22, 0, '0000-00-00', '2020-06-18', '21:48:58', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (38, 2, 6, 'SHANKAR BASU PANDEY', 'Male', '2020-06-18', '9999988888', 's@gmail.com', 'male.jpg', '1', 23, 0, '0000-00-00', '2020-06-18', '21:49:31', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (39, 2, 6, 'SANDIP SARKAR', 'Male', '2020-06-18', '', '', 'male.jpg', '1', 24, 0, '0000-00-00', '2020-06-18', '21:49:58', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (40, 3, 6, 'PURNENDU ROY', 'Male', '2020-06-18', '', '', 'male.jpg', '1', 25, 0, '0000-00-00', '2020-06-18', '21:50:32', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (41, 3, 6, 'MOKLESHUR RAHAMAN MAJHI', 'Male', '2020-06-18', '', '', 'male.jpg', '1', 26, 0, '0000-00-00', '2020-06-18', '21:50:50', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (42, 4, 6, 'BROJEN KAYAL', 'Male', '2020-06-18', '', '', 'male.jpg', '1', 27, 0, '0000-00-00', '2020-06-18', '21:52:14', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (43, 4, 6, 'MITA RANI MAITY', 'Male', '2020-06-18', '', '', 'female.jpg', '1', 28, 0, '0000-00-00', '2020-06-18', '21:52:29', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (44, 3, 6, 'BIREN ROY CHOWDHURY', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 29, 0, '0000-00-00', '2020-06-18', '21:53:03', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (45, 7, 10, 'MD. FURQAN TAHIR', 'Male', '2020-06-01', '9988774455', '', 'male.jpg', '1', 30, 0, '0000-00-00', '2020-06-25', '09:09:49', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (46, 7, 10, 'UTPAL BAYEN', 'Male', '1970-01-01', '9988774455', '', 'male.jpg', '1', 31, 0, '0000-00-00', '2020-06-25', '09:15:36', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (47, 7, 10, 'PRIYA NATH GHARAMI', 'Male', '1970-01-01', '7744118855', '', 'male.jpg', '1', 32, 0, '0000-00-00', '2020-06-25', '09:16:06', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (48, 3, 4, 'NARAYAN GOPAL BHATTACHARJEE', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 11, 0, '0000-00-00', '2020-06-27', '08:43:01', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (49, 3, 8, 'KESTO ROY', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 34, 0, '0000-00-00', '2020-06-27', '08:44:42', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (50, 1, 9, 'MOUSUMI PUROKAYET', 'Female', '1970-01-01', '', '', 'female.jpg', '1', 35, 0, '0000-00-00', '2020-06-27', '08:45:51', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (52, 1, 12, 'RAMESHWAR MALLICK', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 36, 0, '0000-00-00', '2020-06-27', '08:46:35', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (53, 1, 12, 'SATYANARAYAN MALLICK', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 37, 0, '0000-00-00', '2020-06-27', '08:46:53', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (54, 5, 5, 'MIR MOSTAFIZUR RAHAMAN', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 38, 0, '0000-00-00', '2020-06-27', '09:04:23', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (55, 5, 5, 'KANCHAN BANDOPADHYAY', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 39, 0, '0000-00-00', '2020-06-27', '09:04:38', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (56, 5, 6, 'SANJIT BISWAS', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 40, 0, '0000-00-00', '2020-06-27', '09:04:52', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (57, 5, 6, 'MD. MOINUL HASAN', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 41, 0, '0000-00-00', '2020-06-27', '09:05:06', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (58, 5, 6, 'AMIT KR. DAS', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 42, 0, '0000-00-00', '2020-06-27', '09:05:17', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (59, 5, 6, 'ARIJIT GHOSH', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 43, 0, '0000-00-00', '2020-06-27', '09:05:31', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (60, 5, 6, 'ARNAB BISWAS ', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 44, 0, '0000-00-00', '2020-06-27', '09:05:42', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (61, 6, 6, 'BAHRAT HALDER', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 45, 0, '0000-00-00', '2020-06-27', '11:19:43', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (62, 6, 6, 'BIKASH DEY', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 46, 0, '0000-00-00', '2020-06-27', '11:20:05', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (63, 6, 6, 'KADRU MARDI', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 47, 0, '0000-00-00', '2020-06-27', '11:20:17', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (64, 6, 6, 'ASISH NAYEK', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 48, 0, '0000-00-00', '2020-06-27', '11:20:31', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (65, 6, 6, 'BHOLANATH PARUI', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 48, 0, '0000-00-00', '2020-06-27', '11:20:45', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (66, 6, 6, 'ARUP GHOSH', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 49, 0, '0000-00-00', '2020-06-27', '11:21:00', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (67, 6, 6, 'SAJAL MONI', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 50, 0, '0000-00-00', '2020-06-27', '11:21:14', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (68, 6, 6, 'KAMRUL HASSAIN', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 51, 0, '0000-00-00', '2020-06-27', '11:21:32', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (69, 6, 6, 'SK. SHANWAZ ALAM', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 52, 0, '0000-00-00', '2020-06-27', '11:21:45', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (70, 6, 6, 'SHYAM GHOSHAL', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 53, 0, '0000-00-00', '2020-06-27', '11:21:56', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (71, 6, 6, 'JAYANTA RAJBANSHI', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 54, 0, '0000-00-00', '2020-06-27', '11:22:16', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (72, 6, 6, 'JAHAN ALI MONDAL', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 55, 0, '0000-00-00', '2020-06-27', '11:22:28', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (73, 6, 8, 'RATHINDRA NATH DAS', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 56, 0, '0000-00-00', '2020-06-27', '11:22:41', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (74, 6, 12, 'RAMJAN ALI ', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 57, 0, '0000-00-00', '2020-06-27', '11:22:57', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (75, 6, 6, 'MANOJ KR ROY', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 58, 0, '0000-00-00', '2020-06-27', '11:23:20', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (76, 6, 10, 'KAZI AFROZ HOSSAIC', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 59, 0, '0000-00-00', '2020-06-27', '11:23:42', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (77, 8, 16, 'SUBINOY DEY', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 60, 0, '0000-00-00', '2020-06-30', '20:58:49', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (78, 8, 14, 'FARUK HOSSAIN BISWAS', 'Male', '1970-01-01', '7894561235', '', 'male.jpg', '1', 61, 0, '0000-00-00', '2020-06-30', '21:11:37', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (79, 8, 14, 'SOURAV GOLDAR', 'Male', '1970-01-01', '4567891234', '', 'male.jpg', '1', 62, 0, '0000-00-00', '2020-06-30', '21:12:16', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (80, 8, 13, 'PRODIP SARKAR', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 63, 0, '0000-00-00', '2020-06-30', '21:05:36', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (81, 8, 13, 'SUBHANKAR SAHA', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 64, 0, '0000-00-00', '2020-06-30', '21:06:00', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (82, 8, 17, 'SAGAR MUKHERJEE', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 65, 0, '0000-00-00', '2020-06-30', '21:07:14', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (83, 8, 17, 'TUTAN GHOSH', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 66, 0, '0000-00-00', '2020-06-30', '21:07:31', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (84, 8, 17, 'ANIRBAN SETH', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 67, 0, '0000-00-00', '2020-06-30', '21:07:48', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (85, 8, 15, 'ARABINDU MAL', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 68, 0, '0000-00-00', '2020-06-30', '21:08:10', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (86, 8, 15, 'SAIKAT MUKHERJEE', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 69, 0, '0000-00-00', '2020-06-30', '21:08:24', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (87, 8, 15, 'SOURAV MUKHERJEE', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 70, 0, '0000-00-00', '2020-06-30', '21:08:49', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (88, 8, 15, 'ATANU NANSHI', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 71, 0, '0000-00-00', '2020-06-30', '21:09:09', 1, 1);
INSERT INTO `staff` (`st_id`, `st_section`, `st_designation`, `stname`, `gender`, `doj`, `phoneno`, `emailid`, `image`, `batch`, `batch_serial`, `duty_flag`, `last_duty_date`, `st_date`, `st_time`, `st_flag`, `user_id`) VALUES (89, 5, 15, 'SUBHAJIT SANYAL', 'Male', '1970-01-01', '', '', 'male.jpg', '1', 72, 0, '0000-00-00', '2020-06-30', '21:17:17', 1, 1);


#
# TABLE STRUCTURE FOR: staff_leave
#

DROP TABLE IF EXISTS `staff_leave`;

CREATE TABLE `staff_leave` (
  `sl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sl_st_id` int(11) NOT NULL,
  `sl_lid` int(11) NOT NULL,
  `sl_ldate` varchar(255) NOT NULL,
  `sl_remarks` varchar(255) NOT NULL,
  `sl_date` date NOT NULL,
  `sl_time` time NOT NULL,
  `sl_flag` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`sl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `staff_leave` (`sl_id`, `sl_st_id`, `sl_lid`, `sl_ldate`, `sl_remarks`, `sl_date`, `sl_time`, `sl_flag`, `user_id`) VALUES (1, 16, 2, '2020-06-28', 'N/A', '2020-06-27', '15:08:23', 1, 1);
INSERT INTO `staff_leave` (`sl_id`, `sl_st_id`, `sl_lid`, `sl_ldate`, `sl_remarks`, `sl_date`, `sl_time`, `sl_flag`, `user_id`) VALUES (2, 16, 2, '2020-06-29', 'N/A', '2020-06-27', '15:08:23', 1, 1);
INSERT INTO `staff_leave` (`sl_id`, `sl_st_id`, `sl_lid`, `sl_ldate`, `sl_remarks`, `sl_date`, `sl_time`, `sl_flag`, `user_id`) VALUES (3, 16, 1, '2020-06-30', 'N/A', '2020-06-27', '15:08:23', 1, 1);
INSERT INTO `staff_leave` (`sl_id`, `sl_st_id`, `sl_lid`, `sl_ldate`, `sl_remarks`, `sl_date`, `sl_time`, `sl_flag`, `user_id`) VALUES (4, 32, 2, '2020-06-28', 'N/A', '2020-06-27', '15:12:00', 1, 1);
INSERT INTO `staff_leave` (`sl_id`, `sl_st_id`, `sl_lid`, `sl_ldate`, `sl_remarks`, `sl_date`, `sl_time`, `sl_flag`, `user_id`) VALUES (5, 32, 2, '2020-06-30', 'N/A', '2020-06-27', '15:12:00', 1, 1);
INSERT INTO `staff_leave` (`sl_id`, `sl_st_id`, `sl_lid`, `sl_ldate`, `sl_remarks`, `sl_date`, `sl_time`, `sl_flag`, `user_id`) VALUES (6, 54, 3, '2020-06-30', 'N/A', '2020-06-30', '10:56:35', 1, 1);
INSERT INTO `staff_leave` (`sl_id`, `sl_st_id`, `sl_lid`, `sl_ldate`, `sl_remarks`, `sl_date`, `sl_time`, `sl_flag`, `user_id`) VALUES (7, 54, 3, '2020-07-01', 'N/A', '2020-06-30', '10:56:35', 1, 1);


#
# TABLE STRUCTURE FOR: user_group
#

DROP TABLE IF EXISTS `user_group`;

CREATE TABLE `user_group` (
  `ug_id` int(11) NOT NULL AUTO_INCREMENT,
  `ug_name` varchar(255) DEFAULT NULL,
  `ug_permission` text,
  `ug_datetime` datetime DEFAULT NULL,
  `ug_flag` int(11) DEFAULT NULL,
  `ug_userid` int(11) DEFAULT NULL,
  PRIMARY KEY (`ug_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `user_group` (`ug_id`, `ug_name`, `ug_permission`, `ug_datetime`, `ug_flag`, `ug_userid`) VALUES (1, 'Admin', 'a:27:{i:0;s:13:\"createsection\";i:1;s:13:\"updatesection\";i:2;s:13:\"deletesection\";i:3;s:17:\"createdesignation\";i:4;s:17:\"updatedesignation\";i:5;s:17:\"deletedesignation\";i:6;s:11:\"createleave\";i:7;s:11:\"updateleave\";i:8;s:11:\"deleteleave\";i:9;s:14:\"createemployee\";i:10;s:14:\"updateemployee\";i:11;s:14:\"deleteemployee\";i:12;s:16:\"addemployeeleave\";i:13;s:19:\"updateemployeeleave\";i:14;s:19:\"deleteemployeeleave\";i:15;s:12:\"createloduty\";i:16;s:12:\"updateloduty\";i:17;s:12:\"deleteloduty\";i:18;s:10:\"assignduty\";i:19;s:16:\"updateassignduty\";i:20;s:14:\"viewassignduty\";i:21;s:17:\"createdisposition\";i:22;s:15:\"editdisposition\";i:23;s:10:\"dutyreport\";i:24;s:11:\"createusers\";i:25;s:11:\"updateusers\";i:26;s:15:\"createusergroup\";}', '2020-07-09 09:06:00', 1, 1);
INSERT INTO `user_group` (`ug_id`, `ug_name`, `ug_permission`, `ug_datetime`, `ug_flag`, `ug_userid`) VALUES (2, 'User', 'a:6:{i:0;s:12:\"createloduty\";i:1;s:12:\"updateloduty\";i:2;s:12:\"deleteloduty\";i:3;s:10:\"assignduty\";i:4;s:16:\"updateassignduty\";i:5;s:14:\"viewassignduty\";}', '2020-07-02 18:50:00', 1, 1);
INSERT INTO `user_group` (`ug_id`, `ug_name`, `ug_permission`, `ug_datetime`, `ug_flag`, `ug_userid`) VALUES (3, 'CPC', 'a:17:{i:0;s:11:\"createleave\";i:1;s:11:\"updateleave\";i:2;s:11:\"deleteleave\";i:3;s:14:\"createemployee\";i:4;s:14:\"updateemployee\";i:5;s:14:\"deleteemployee\";i:6;s:16:\"addemployeeleave\";i:7;s:19:\"updateemployeeleave\";i:8;s:19:\"deleteemployeeleave\";i:9;s:12:\"createloduty\";i:10;s:12:\"updateloduty\";i:11;s:12:\"deleteloduty\";i:12;s:10:\"assignduty\";i:13;s:16:\"updateassignduty\";i:14;s:14:\"viewassignduty\";i:15;s:17:\"createdisposition\";i:16;s:15:\"editdisposition\";}', '2020-07-09 13:57:00', 1, 1);


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_ugid` int(11) DEFAULT NULL,
  `u_title` varchar(255) NOT NULL,
  `u_username` varchar(255) NOT NULL,
  `u_password` varchar(255) NOT NULL,
  `u_datetime` datetime NOT NULL,
  `u_flag` int(11) NOT NULL,
  `u_userid` int(11) NOT NULL,
  `u_ip` varchar(255) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`u_id`, `u_ugid`, `u_title`, `u_username`, `u_password`, `u_datetime`, `u_flag`, `u_userid`, `u_ip`) VALUES (1, 1, 'Anirban Seth', 'anirban', 'o9VumscQ8oDjOtW+fO4itsgow9mvctJ5x85/3WrQw5ILrZRHmGFSWrP4gj+lxuP4Q8iftiatSDpJkjBtv7MVCw==', '2020-06-24 20:36:00', 1, 1, '::1');
INSERT INTO `users` (`u_id`, `u_ugid`, `u_title`, `u_username`, `u_password`, `u_datetime`, `u_flag`, `u_userid`, `u_ip`) VALUES (2, 2, 'Aminur Rahaman', 'user1@pms.com', 'lk9qfUsqkoQlGxcXzF4kPJOMwwKDzy5bUsq1LXqycqdhmOwfY2Jk89kh/ymijNnfaV6kBCm/yRb+yYfJWn31fw==', '2020-06-24 19:56:00', 1, 2, '::1');
INSERT INTO `users` (`u_id`, `u_ugid`, `u_title`, `u_username`, `u_password`, `u_datetime`, `u_flag`, `u_userid`, `u_ip`) VALUES (3, 2, 'Manoj Roy', 'user2@pms.com', 'xElJkmRoBu3v70UKyd3xrAiJ0aN03+Kgg0IyS26jnZL5NL8goT2NgTGeNZot2Ji5+tyDKn2RBGUSH65BeTqAfg==', '2020-06-26 09:17:00', 1, 1, '::1');


#
# TABLE STRUCTURE FOR: users_log
#

DROP TABLE IF EXISTS `users_log`;

CREATE TABLE `users_log` (
  `id` int(11) NOT NULL,
  `User_Id` int(11) NOT NULL,
  `ipadd` varchar(255) NOT NULL,
  `Log_Date` date NOT NULL DEFAULT '0000-00-00',
  `Log_Time` time NOT NULL DEFAULT '00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

